/*
 * Class: CMSC203 
 * Instructor:Griegory Grinberg
 * Description: helps the user computer's internet connectivity
 * Due: 2/15/2021
 * Platform/compiler: eclipse IDE
 * I pledge that I have completed the programming assignment independently.
   I have not copied the code from a student or any source.
   I have not given my code to any student.
   Print your Name here: Emmanuel Abebe
*/

package packages;

import java.util.*;

public class WIFIDiagnosis {
	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		String status;
		
		System.out.println("if you have a problem with internt connectivity, this WiFi Diagnosis might work.");
		
		System.out.println("reboot your computer\nAre you able to connect with the internt? (yes or no)");
		status = in.nextLine();
		if(status.equals("no")) {
			System.out.println("Reboot your router\nAre you able to connect with the internt? (yes or no)");
			status = in.nextLine();
			
			if(status.equals("no")) {
				System.out.println("Make sure the cables connecting the router are firmly pplugged in and power is getting to the router\nAre you able to connect with the internt? (yes or no)");
				status = in.nextLine();
				
				if(status.equals("no")) {
					System.out.println("Move the computer closer to the router and try connecting\nAre you able to connect with the internt? (yes or no)");
					status = in.nextLine();
				
					if(status.equals("no")) {
						System.out.println("Contact your ISP");
					}
				}
			}	
		}
		System.out.println("Done");
		
	}
}
